package calculator;

import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;


public class Calculator extends Frame {

	String inputValue; 									// ���� �Է����� ����
	int result; 										// �߰� ��� ���
	char lastOp; 										// ���� ���� ������
	TextField tf;
	JButton btn13, btn20 ,btn21, btn22, btn23, btn28;	// ������
	
	public Calculator() {
	
		// �ؽ�Ʈ �ʵ�
		tf = new TextField();
		tf.setBounds(20, 60, 212, 50);
		tf.setText("0");
		add(tf);

		NumberHandler n = new NumberHandler();
		CalcHandler s = new CalcHandler();
		
		// 1��
		Button btn1 = new Button("MC");
		btn1.setBounds(20, 113, 34, 27);
		add(btn1);

		Button btn2 = new Button("��");
		btn2.setBounds(20, 145, 34, 27);
		add(btn2);
		btn2.addActionListener(new Backspace());		// �齺���̽� ������ �̺�Ʈ

		Button btn3 = new Button("7");
		btn3.setBounds(20, 177, 34, 27);
		btn3.addActionListener(n);
		add(btn3);

		Button btn4 = new Button("4");
		btn4.setBounds(20, 209, 34, 27);
		btn4.addActionListener(n);
		add(btn4);

		Button btn5 = new Button("1");
		btn5.setBounds(20, 241, 34, 27);
		btn5.addActionListener(n);
		add(btn5);

		Button btn6 = new Button("0");
		btn6.setBounds(20, 273, 73, 27);
		btn6.addActionListener(n);
		add(btn6);

		// 2��
		Button btn7 = new Button("MR");
		btn7.setBounds(59, 113, 34, 27);
		add(btn7);

		Button btn8 = new Button("CE");
		btn8.setBounds(59, 145, 34, 27);
		add(btn8);

		Button btn9 = new Button("8");
		btn9.setBounds(59, 177, 34, 27);
		btn9.addActionListener(n);
		add(btn9);

		Button btn10 = new Button("5");
		btn10.setBounds(59, 209, 34, 27);
		btn10.addActionListener(n);
		add(btn10);

		Button btn11 = new Button("2");
		btn11.setBounds(59, 241, 34, 27);
		btn11.addActionListener(n);
		add(btn11);

		// 3��
		Button btn12 = new Button("MS");
		btn12.setBounds(98, 113, 42, 27);
		add(btn12);

		btn13 = new JButton("C");
		btn13.setBounds(98, 145, 42, 27);
		btn13.addActionListener(s);
		add(btn13);

		Button btn14 = new Button("9");
		btn14.setBounds(98, 177, 42, 27);
		btn14.addActionListener(n);
		add(btn14);

		Button btn15 = new Button("6");
		btn15.setBounds(98, 209, 42, 27);
		btn15.addActionListener(n);
		add(btn15);

		Button btn16 = new Button("3");
		btn16.setBounds(98, 241, 42, 27);
		btn16.addActionListener(n);
		add(btn16);

		Button btn17 = new Button(".");
		btn17.setBounds(98, 273, 42, 27);
		add(btn17);

		// 4��
		Button btn18 = new Button("M+");
		btn18.setBounds(145, 113, 41, 27);
		add(btn18);

		Button btn19 = new Button("��");
		btn19.setBounds(145, 145, 41, 27);
		add(btn19);

		btn20 = new JButton("/");
		btn20.setBounds(145, 177, 41, 27);
		btn20.addActionListener(s);
		add(btn20);

		btn21 = new JButton("*");
		btn21.setBounds(145, 209, 41, 27);
		btn21.addActionListener(s);
		add(btn21);

		btn22 = new JButton("-");
		btn22.setBounds(145, 241, 41, 27);
		btn22.addActionListener(s);
		add(btn22);

		btn23 = new JButton("+");
		btn23.setBounds(145, 273, 41, 27);
		btn23.addActionListener(s);
		add(btn23);

		// 5��
		Button btn24 = new Button("M-");
		btn24.setBounds(190, 113, 41, 27);
		add(btn24);

		Button btn25 = new Button("��");
		btn25.setBounds(190, 145, 41, 27);
		add(btn25);

		Button btn26 = new Button("%");
		btn26.setBounds(190, 177, 41, 27);
		add(btn26);

		Button btn27 = new Button("1/x");
		btn27.setBounds(190, 209, 41, 27);
		add(btn27);

		btn28 = new JButton("=");
		btn28.setBounds(190, 241, 41, 59);
		btn28.addActionListener(s);
		add(btn28);

		// ��ü ���̾ƿ�
		setTitle("����");
		setLayout(null);
		setSize(250, 323);
		setVisible(true);

		// ������ �̺�Ʈ
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

	}

	// �齺���̽� ������ �̺�Ʈ ó��
	public class Backspace implements ActionListener {
		public void actionPerformed(ActionEvent e) {
		        String inputValue = tf.getText();
		        tf.setText(inputValue.substring(0, inputValue.length() - 1));
		        if(tf.getText().equals("")) tf.setText("0");
		}
	}
	
	// ���ڹ�ư�� �̺�Ʈ ó��
	class NumberHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s = e.getActionCommand(); 			// Ŭ���� ��ư�� ���̺�
			if (inputValue == null) {
				if (s.equals("0"))
					return;								// ù �ڸ��̸鼭 0�̸� ����
				else
					inputValue = new String();			// ù �ڸ��̸� String ��ü ����
			}
			if (inputValue.length() >= 9)
				return; 								// 9�ڸ� ������ ����
			inputValue += s;							// �ι�° �����̸� ���� ���� �����̱�
			tf.setText(inputValue);						// ���� ���� ȭ�鿡 ǥ��
		}
	}

	// ��Ÿ ��� ��ư�� �̺�Ʈ ó��
	class CalcHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton source = (JButton) e.getSource();
			int value;

			// �����
			if (source == btn13) {
				tf.setText("0");						// ȭ�� �� �� ���� �ʱ�ȭ
				inputValue = null; 						// String Ÿ���� ���� ����
				lastOp = 0; 							// char Ÿ���� ������ ������
				result = 0; 							// int Ÿ���� �߰� ��� ���
				return;
			}
			// ��Ÿ ��� +,-,*,/
			if (inputValue != null) {
				value = Integer.parseInt(inputValue);
				switch (lastOp) {
				case '+':
					result += value;
					break;
				case '-':
					result -= value;
					break;
				case '*':
					result *= value;
					break;
				case '/':
					result /= value;
					break;
				default:
					result = value;
					break;
				}
				tf.setText(Integer.toString(result));

			}
			inputValue = null;
			lastOp = source.getText().charAt(0);
		}
	}

	public static void main(String[] args) {
		new Calculator();
	}

}
